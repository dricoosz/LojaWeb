/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package loja.web;

/**
 *
 * @author Usuario
 */
public class GerenciarProduto {

    public void buscarProduto(int codigo){
        
    }
    public void cadastrarProduto(int codigo, String titulo, double valor){
        
    }
    public void excluirProduto(int codigo){
        
    }
    public void alterarProduto(int codigo, String titulo, double valor){
        
    }

}
